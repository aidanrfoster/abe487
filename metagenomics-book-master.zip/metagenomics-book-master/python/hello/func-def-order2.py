#!/usr/bin/env python3

def foo():
    print('This is foo')

print('Starting the program')
foo()
print('Ending the program')
