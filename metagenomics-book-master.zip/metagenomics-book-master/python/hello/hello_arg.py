#!/usr/bin/env python3

import sys

args = sys.argv
print('Hello, ' + args[1] + '!')
