#!/usr/bin/env python3

print('Starting the program')
foo()
print('Ending the program')

def foo():
    print('This is foo')
