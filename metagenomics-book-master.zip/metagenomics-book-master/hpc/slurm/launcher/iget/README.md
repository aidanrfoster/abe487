# iget

I needed to pull down a list of reads from the shared "iMicrobe" directory
in the Cyverse Data Store, so I created a file of "iget" commands to fetch
the files and used the Launcher to run these.

```
$ sbatch iget.sh
```
