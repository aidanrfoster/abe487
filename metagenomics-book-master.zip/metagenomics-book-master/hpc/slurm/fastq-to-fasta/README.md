# FASTAQ-to-FASTA

Use Launcher and Fastx Toolkit to convert FASTQ files to FASTA.

Type "make".
