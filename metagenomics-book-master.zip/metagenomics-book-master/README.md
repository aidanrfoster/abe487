# Metagenomics Book Examples

Example code from metagenomics book 
(https://www.gitbook.com/book/kyclark/metagenomics/details).

# Author

Ken Youens-Clark <kyclark@gmail.com>
