# Gapminder

Data from the Gapminder project for Unix work.
