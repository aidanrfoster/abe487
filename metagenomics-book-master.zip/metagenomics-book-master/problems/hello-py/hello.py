#!/usr/bin/env python3
"""say hello to the arguments"""

print('OK')
