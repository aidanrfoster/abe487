#!/usr/bin/env python3
"""count the vowels in a word"""

print('OK')
