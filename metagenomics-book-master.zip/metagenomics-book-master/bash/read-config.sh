#!/bin/bash

source config1.sh
echo "$GREETING, $NAME!"
