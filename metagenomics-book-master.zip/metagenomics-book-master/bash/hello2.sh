#!/bin/bash

NAME="Newman"
echo "Hello," $NAME
NAME="Jerry"
echo "Hello, $NAME"
