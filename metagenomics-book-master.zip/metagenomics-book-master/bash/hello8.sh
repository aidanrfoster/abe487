#!/bin/bash

echo "Hello, ${WHOM:-Marie}"
