export NAME="François"
export GREETING="Salut"
