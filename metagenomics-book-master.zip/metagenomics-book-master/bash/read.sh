#!/bin/bash

set -u
echo -n "What is your name? "
read NAME
echo "Would you like to play a nice game of chess, $NAME?"
