#!/bin/bash

echo "Hello, ${1:-Stranger}!"
