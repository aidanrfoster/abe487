#!/bin/bash

echo "Num of args    : \"$#\""
echo "String of args : \"$@\""
echo "Name of program: \"$0\""
echo "First arg      : \"$1\""
echo "Second arg     : \"$2\""
