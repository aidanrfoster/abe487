export NAME="Merry Boy"
export GREETING="Good morning"
